#include<iostream>
#include<fstream>

using namespace std;

int main(){
    string st2;
    // Opening files using constructor and reading it
    ifstream in("sample60.txt"); // Read operation
    
    getline(in, st2);  
    cout<<st2;

    return 0;
}
